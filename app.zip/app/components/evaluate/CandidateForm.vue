<script setup lang="ts">
import ScoresEditor from '~/components/ScoresEditor.vue'
import type { TestName } from '~/data/testSchemas'

const props = defineProps<{
	candidate: any
	candidateIndex: number
	testSchemas: readonly { name: string; label?: string }[]
	schemaFor: (name: TestName) => any
}>()

const emit = defineEmits<{
	(e: 'removeCandidate', idx: number): void
	(e: 'addTest', candidateIdx: number): void
	(e: 'removeTest', candidateIdx: number, testIdx: number): void
}>()

function onChangeTestName(testIdx: number, next: string) {
	props.candidate.resultadosPruebas[testIdx].name = next
	// keep scores object if user already typed, but ensure object exists
	if (!props.candidate.resultadosPruebas[testIdx].scores || typeof props.candidate.resultadosPruebas[testIdx].scores !== 'object') {
		props.candidate.resultadosPruebas[testIdx].scores = {}
	}
}
</script>

<template>
	<div class="space-y-6">
		<div class="flex flex-wrap items-center justify-between gap-2">
			<div class="text-sm font-semibold">Candidato</div>
			<button
				class="rounded-lg border px-3 py-2 text-sm disabled:opacity-60"
				type="button"
				:disabled="candidateIndex === 0 && false"
				@click="emit('removeCandidate', candidateIndex)"
			>
				Eliminar candidato
			</button>
		</div>

		<div class="rounded-2xl border p-5">
			<div class="grid gap-4 md:grid-cols-2">
				<div>
					<label class="text-sm font-medium">Nombre</label>
					<input v-model="candidate.nombre" maxlength="100" class="mt-1 w-full rounded-lg border px-3 py-2" />
				</div>

				<div class="flex items-end gap-2">
					<label class="flex items-center gap-2 text-sm font-medium">
						<input type="checkbox" v-model="candidate.cvEnabled" />
						Incluir CV
					</label>
					<label class="flex items-center gap-2 text-sm font-medium">
						<input type="checkbox" v-model="candidate.entrevistaEnabled" />
						Incluir entrevista
					</label>
				</div>
			</div>
		</div>

		<!-- CV -->
		<div v-if="candidate.cvEnabled" class="rounded-2xl border p-5">
			<div class="mb-3 text-sm font-semibold">CV</div>
			<div class="grid gap-4 md:grid-cols-2">
				<div class="md:col-span-2">
					<label class="text-sm font-medium">Perfil</label>
					<textarea v-model="candidate.cv.perfil" maxlength="150" class="mt-1 w-full rounded-lg border px-3 py-2" rows="2" />
				</div>

				<div>
					<label class="text-sm font-medium">Aspiración salarial</label>
					<input v-model.number="candidate.cv.aspiracionSalarial" type="number" min="0" class="mt-1 w-full rounded-lg border px-3 py-2" />
				</div>

				<div>
					<label class="text-sm font-medium">Fecha nacimiento (DD/MM/YYYY)</label>
					<input v-model="candidate.cv.fechaNacimiento" type="date" class="mt-1 w-full rounded-lg border px-3 py-2" />
				</div>

				<div>
					<label class="text-sm font-medium">Profesión</label>
					<input v-model="candidate.cv.profesion" maxlength="50" class="mt-1 w-full rounded-lg border px-3 py-2" />
				</div>

				<div>
					<label class="text-sm font-medium">Nivel educativo</label>
					<input v-model="candidate.cv.nivelEducativo" class="mt-1 w-full rounded-lg border px-3 py-2" />
				</div>
			</div>
		</div>

		<!-- TESTS -->
		<div class="rounded-2xl border p-5">
			<div class="mb-3 flex items-center justify-between">
				<div class="text-sm font-semibold">Resultados de pruebas</div>
				<button class="rounded-lg bg-slate-900 px-3 py-2 text-sm text-white" type="button" @click="emit('addTest', candidateIndex)">
					+ Agregar test
				</button>
			</div>

			<div class="space-y-4">
				<div v-for="(rp, ti) in candidate.resultadosPruebas" :key="ti" class="rounded-xl border p-4">
					<div class="flex flex-wrap items-center justify-between gap-2">
						<div class="w-full md:w-[280px]">
							<label class="text-xs font-semibold text-slate-600">Test</label>
							<select
								class="mt-1 w-full rounded-lg border px-3 py-2 text-sm"
								:value="rp.name"
								@change="onChangeTestName(ti, ($event.target as HTMLSelectElement).value)"
							>
								<option v-for="t in testSchemas" :key="t.name" :value="t.name">
									{{ t.label ?? t.name }}
								</option>
							</select>
						</div>

						<button class="rounded-lg border px-3 py-2 text-sm" type="button" @click="emit('removeTest', candidateIndex, ti)">
							Eliminar
						</button>
					</div>

					<div class="mt-4">
						<ScoresEditor
							v-if="rp.name"
							:schema="schemaFor(rp.name as TestName).scores"
							v-model="rp.scores"
						/>
					</div>
				</div>
			</div>
		</div>

		<!-- INTERVIEW -->
		<div v-if="candidate.entrevistaEnabled" class="rounded-2xl border p-5">
			<div class="mb-3 text-sm font-semibold">Entrevista</div>

			<div class="grid gap-4 md:grid-cols-2">
				<div>
					<label class="text-sm font-medium">Calificación (1..10)</label>
					<input v-model.number="candidate.resultadoEntrevista.calificacion" type="number" min="1" max="10" class="mt-1 w-full rounded-lg border px-3 py-2" />
				</div>

				<div>
					<label class="text-sm font-medium">Concepto</label>
					<input v-model="candidate.resultadoEntrevista.concepto" maxlength="100" class="mt-1 w-full rounded-lg border px-3 py-2" />
				</div>
			</div>
		</div>
	</div>
</template>
