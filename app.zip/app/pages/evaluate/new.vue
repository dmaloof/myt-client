<script setup lang="ts">
import { checkPromptInjection } from '~/utils/promptGuard'
import { TEST_SCHEMAS, getTestSchema, type TestName } from '~/data/testSchemas'

import PerfilForm from '~/components/evaluate/PerfilForm.vue'
import CulturaForm from '~/components/evaluate/CulturaForm.vue'
import CandidateForm from '~/components/evaluate/CandidateForm.vue'
import ConfigForm from '~/components/evaluate/ConfigForm.vue'

definePageMeta({ layout: 'default' })

const tabs = ['Configuración', 'Perfil', 'Cultura', 'Candidatos'] as const
type Tab = typeof tabs[number]
const tab = ref<Tab>('Configuración')

/** ------------ constants (dropdowns, chips) ------------ **/
const NIVEL_PROFESIONAL = ["No aplica", "Bachiller", "Técnico", "Tecnólogo", "Profesional", "Especialista", "Doctorado"] as const
const IDIOMAS = ["Inglés", "Chino Mandarín", "Francés", "Portugués", "Alemán", "Italiano", "otro"] as const
const MODALIDAD = ["Presencial", "Remoto", "Híbrido"] as const
const SENIORITY = ["Junior", "Semi-Senior", "Senior", "Liderazgo"] as const

const CULT_ESTILO_TRABAJO = ["COLABORATIVO", "AUTONOMO", "ORIENTADO AL LOGRO", "ORIENTADO AL PROCESO", "MIXTO"] as const
const CULT_RITMO = ["RAPIDO", "MODERADO", "ESTABLE", "VARIABLE"] as const
const CULT_TOL_ERR = ["ALTA", "MEDIA", "BAJA"] as const
const CULT_ESTILO_LIDERAZGO = ["PARTICIPATIVO", "COACHING", "DIRECTIVO", "ORIENTADO A RESULTADOS", "SERVICIAL"] as const
const CULT_NIVEL_ESTRUCTURA = ["ALTA", "MEDIA", "BAJA"] as const

const SERVICE = ["FULL_REPORT", "CANDIDATE", "RANKING"] as const
const REPORT_MODE = ["EXECUTIVE", "LIGHT"] as const

const DEFAULT_TEST_NAME = "" as TestName

/** ------------ state ------------ **/
const form = reactive({
	perfil: {
		cargo: '',
		descripcion: '',
		funciones: [''],
		requisitos: {
			formacion: {
				nivelProfesional: 'No aplica',
				carrerasAfines: '',
				idiomas: [] as string[],
				conocimientosEspecificos: '',
			},
			experienciaLaboral: {
				tiempo: 0,
				areas: '',
			},
		},
		competencias: {
			tecnicas: [''],
			conductuales: [{ competencia: '', nivel: 'Medio' }],
		},
		identificacionDelCargo: {
			personalACargo: false,
			modalidad: 'Presencial',
			disponibilidadViajes: false,
		},
		nivelSeniority: null as null | string,
	},

	cultura: {
		enabled: false,
		valores: [''],
		estiloTrabajo: 'COLABORATIVO',
		ritmo: 'MODERADO',
		toleranciaAlError: 'MEDIA',
		comportamientosDeseados: [''],
		comportamientosNoAceptados: [''],
		estiloLiderazgo: 'PARTICIPATIVO',
		nivelEstructura: 'MEDIA',
	},

	candidatos: [
		{
			nombre: '',
			cvEnabled: false,
			cv: {
				perfil: '',
				aspiracionSalarial: 0,
				fechaNacimiento: '',
				profesion: '',
				nivelEducativo: 'No aplica',
				experienciaLaboral: [{ empresa: '', cargo: '', area: '', funciones: '', fechaInicio: '', fechaFin: '' }],
				formacionAcademica: [{ institucion: '', carrera: '', nivel: 'Bachiller', estado: 'Terminado', fechaInicio: '' }],
				idiomas: [{ idioma: '', nivelEscritura: 'MEDIA', nivelLectura: 'MEDIA', nivelConversacion: 'MEDIA' }],
			},
			resultadosPruebas: [{ name: DEFAULT_TEST_NAME, scores: {} as any }],
			entrevistaEnabled: false,
			resultadoEntrevista: {
				preguntas: [{ pregunta: '', respuesta: '', calificacion: 5, concepto: '' }],
				calificacion: 5,
				concepto: '',
			},
		},
	],

	config: {
		service: 'RANKING' as 'FULL_REPORT' | 'CANDIDATE' | 'RANKING',
		reportMode: 'EXECUTIVE' as 'EXECUTIVE' | 'LIGHT',
		ponderaciones: { cv: 0, pruebas: 10, entrevista: 0 },
	},
})

/** ------------ prompt injection guard ------------ **/
type GuardIssue = { path: string; hits: ReturnType<typeof checkPromptInjection> }
const guardIssues = ref<GuardIssue[]>([])

function scanFreeText(): GuardIssue[] {
	const issues: GuardIssue[] = []
	const push = (path: string, text: string) => {
		const hits = checkPromptInjection(text)
		if (hits.length) issues.push({ path, hits })
	}

	// PERFIL
	push('perfil.cargo', form.perfil.cargo)
	push('perfil.descripcion', form.perfil.descripcion)
	form.perfil.funciones.forEach((v, i) => push(`perfil.funciones[${i}]`, v))
	push('perfil.requisitos.formacion.carrerasAfines', form.perfil.requisitos.formacion.carrerasAfines)
	push('perfil.requisitos.formacion.conocimientosEspecificos', form.perfil.requisitos.formacion.conocimientosEspecificos)
	push('perfil.requisitos.experienciaLaboral.areas', form.perfil.requisitos.experienciaLaboral.areas)
	form.perfil.competencias.tecnicas.forEach((v, i) => push(`perfil.competencias.tecnicas[${i}]`, v))
	form.perfil.competencias.conductuales.forEach((v, i) => push(`perfil.competencias.conductuales[${i}].competencia`, v.competencia))

	// CULTURA
	if (form.cultura.enabled) {
		form.cultura.valores.forEach((v, i) => push(`cultura.valores[${i}]`, v))
		form.cultura.comportamientosDeseados.forEach((v, i) => push(`cultura.comportamientosDeseados[${i}]`, v))
		form.cultura.comportamientosNoAceptados.forEach((v, i) => push(`cultura.comportamientosNoAceptados[${i}]`, v))
	}

	// CANDIDATOS
	form.candidatos.forEach((c, ci) => {
		push(`candidatos[${ci}].nombre`, c.nombre)
		if (c.cvEnabled) {
			push(`candidatos[${ci}].cv.perfil`, c.cv.perfil)
			push(`candidatos[${ci}].cv.profesion`, c.cv.profesion)
			c.cv.experienciaLaboral.forEach((x, xi) => {
				push(`candidatos[${ci}].cv.experienciaLaboral[${xi}].empresa`, x.empresa)
				push(`candidatos[${ci}].cv.experienciaLaboral[${xi}].cargo`, x.cargo)
				push(`candidatos[${ci}].cv.experienciaLaboral[${xi}].area`, x.area)
				push(`candidatos[${ci}].cv.experienciaLaboral[${xi}].funciones`, x.funciones)
			})
			c.cv.formacionAcademica.forEach((x, xi) => {
				push(`candidatos[${ci}].cv.formacionAcademica[${xi}].institucion`, x.institucion)
				push(`candidatos[${ci}].cv.formacionAcademica[${xi}].carrera`, x.carrera)
			})
			c.cv.idiomas.forEach((x, xi) => push(`candidatos[${ci}].cv.idiomas[${xi}].idioma`, x.idioma))
		}
		if (c.entrevistaEnabled) {
			c.resultadoEntrevista.preguntas.forEach((p, pi) => {
				push(`candidatos[${ci}].resultadoEntrevista.preguntas[${pi}].pregunta`, p.pregunta)
				push(`candidatos[${ci}].resultadoEntrevista.preguntas[${pi}].respuesta`, p.respuesta)
				push(`candidatos[${ci}].resultadoEntrevista.preguntas[${pi}].concepto`, p.concepto)
			})
			push(`candidatos[${ci}].resultadoEntrevista.concepto`, c.resultadoEntrevista.concepto)
		}
	})

	return issues
}

/** ------------ config logic ------------ **/
const anyCvPresent = computed(() => form.candidatos.some(c => c.cvEnabled))
const anyInterviewPresent = computed(() => form.candidatos.some(c => c.entrevistaEnabled))

watch([anyCvPresent, anyInterviewPresent], () => {
	if (!anyCvPresent.value) form.config.ponderaciones.cv = 0
	if (!anyInterviewPresent.value) form.config.ponderaciones.entrevista = 0

	const sum = form.config.ponderaciones.cv + form.config.ponderaciones.pruebas + form.config.ponderaciones.entrevista
	if (sum !== 10) {
		const fixed = 10 - (form.config.ponderaciones.cv + form.config.ponderaciones.entrevista)
		form.config.ponderaciones.pruebas = Math.max(1, Math.min(10, fixed))
	}
})

const ponderacionesSum = computed(() =>
	form.config.ponderaciones.cv + form.config.ponderaciones.pruebas + form.config.ponderaciones.entrevista
)

/**------------- JSON import Helpers ------------**/
const fileInput = ref<HTMLInputElement | null>(null)

function isNonEmptyValue(v: any) {
	if (v == null) return false
	if (typeof v === 'string') return v.trim().length > 0
	if (Array.isArray(v)) return v.some(isNonEmptyValue)
	if (typeof v === 'object') return Object.values(v).some(isNonEmptyValue)
	if (typeof v === 'number') return true
	if (typeof v === 'boolean') return true
	return false
}

function parseYearsToNumber(input: any): number {
	if (typeof input === 'number') return input
	if (typeof input !== 'string') return 0
	const m = input.match(/(\d+([.,]\d+)?)/)
	if (!m) return 0
	return Number(m[1]?.replace(',', '.'))
}

function replaceArray<T>(target: T[], next: T[]) {
	target.splice(0, target.length, ...next)
}

function safeStringArray(arr: any): string[] {
	if (!Array.isArray(arr)) return []
	return arr.filter((x) => typeof x === 'string').map((x) => x.trim()).filter(Boolean)
}

function normalizeTestName(name: any): TestName {
	const s = String(name ?? '').trim()
	const found = TEST_SCHEMAS.find(t => t.name === s)
	return (found?.name ?? DEFAULT_TEST_NAME) as TestName
}

function applyTemplate(template: any) {
	if (!template || typeof template !== 'object') throw new Error('Invalid JSON: expected an object')

	// PERFIL
	if (template.perfil) {
		form.perfil.cargo = String(template.perfil.cargo ?? '')
		form.perfil.descripcion = String(template.perfil.descripcion ?? '')
		replaceArray(form.perfil.funciones, safeStringArray(template.perfil.funciones))
		if (!form.perfil.funciones.length) form.perfil.funciones.push('')

		const f = template.perfil.requisitos?.formacion ?? {}
		form.perfil.requisitos.formacion.nivelProfesional = String(f.nivelProfesional ?? 'No aplica')
		form.perfil.requisitos.formacion.carrerasAfines = String(f.carrerasAfines ?? '')
		replaceArray(form.perfil.requisitos.formacion.idiomas, safeStringArray(f.idiomas))
		form.perfil.requisitos.formacion.conocimientosEspecificos = String(f.conocimientosEspecificos ?? '')

		const ex = template.perfil.requisitos?.experienciaLaboral ?? {}
		form.perfil.requisitos.experienciaLaboral.tiempo = parseYearsToNumber(ex.tiempo)
		form.perfil.requisitos.experienciaLaboral.areas = String(ex.areas ?? '')

		const comp = template.perfil.competencias ?? {}
		replaceArray(form.perfil.competencias.tecnicas, safeStringArray(comp.tecnicas))
		if (!form.perfil.competencias.tecnicas.length) form.perfil.competencias.tecnicas.push('')

		const cond = Array.isArray(comp.conductuales) ? comp.conductuales : []
		replaceArray(
			form.perfil.competencias.conductuales,
			cond.slice(0, 5).map((x: any) => ({
				competencia: String(x?.competencia ?? ''),
				nivel: String(x?.nivel ?? 'Medio'),
			}))
		)
		if (!form.perfil.competencias.conductuales.length) {
			form.perfil.competencias.conductuales.push({ competencia: '', nivel: 'Medio' })
		}

		const idc = template.perfil.identificacionDelCargo ?? {}
		form.perfil.identificacionDelCargo.personalACargo = Boolean(idc.personalACargo)
		form.perfil.identificacionDelCargo.modalidad = String(idc.modalidad ?? 'Presencial')
		form.perfil.identificacionDelCargo.disponibilidadViajes = Boolean(idc.disponibilidadViajes)

		form.perfil.nivelSeniority = template.perfil.nivelSeniority ? String(template.perfil.nivelSeniority) : null
	}

	// CULTURA
	if (template.cultura && typeof template.cultura === 'object') {
		form.cultura.enabled = isNonEmptyValue(template.cultura)
		replaceArray(form.cultura.valores, safeStringArray(template.cultura.valores))
		if (!form.cultura.valores.length) form.cultura.valores.push('')
		form.cultura.estiloTrabajo = String(template.cultura.estiloTrabajo ?? form.cultura.estiloTrabajo)
		form.cultura.ritmo = String(template.cultura.ritmo ?? form.cultura.ritmo)
		form.cultura.toleranciaAlError = String(template.cultura.toleranciaAlError ?? form.cultura.toleranciaAlError)
		replaceArray(form.cultura.comportamientosDeseados, safeStringArray(template.cultura.comportamientosDeseados))
		if (!form.cultura.comportamientosDeseados.length) form.cultura.comportamientosDeseados.push('')
		replaceArray(form.cultura.comportamientosNoAceptados, safeStringArray(template.cultura.comportamientosNoAceptados))
		if (!form.cultura.comportamientosNoAceptados.length) form.cultura.comportamientosNoAceptados.push('')
		form.cultura.estiloLiderazgo = String(template.cultura.estiloLiderazgo ?? form.cultura.estiloLiderazgo)
		form.cultura.nivelEstructura = String(template.cultura.nivelEstructura ?? form.cultura.nivelEstructura)
	} else {
		form.cultura.enabled = false
	}

	// CANDIDATOS
	if (Array.isArray(template.candidatos)) {
		const incoming = template.candidatos.slice(0, 10)
		form.candidatos.splice(0, form.candidatos.length)

		for (const c of incoming) {
			const cvObj = c?.cv
			const entrevistaObj = c?.resultadoEntrevista

			form.candidatos.push({
				nombre: String(c?.nombre ?? ''),
				cvEnabled: Boolean(cvObj && typeof cvObj === 'object' && isNonEmptyValue(cvObj)),
				cv: {
					perfil: String(cvObj?.perfil ?? ''),
					aspiracionSalarial: Number(cvObj?.aspiracionSalarial ?? 0),
					fechaNacimiento: String(cvObj?.fechaNacimiento ?? ''),
					profesion: String(cvObj?.profesion ?? ''),
					nivelEducativo: String(cvObj?.nivelEducativo ?? 'No aplica'),
					experienciaLaboral: Array.isArray(cvObj?.experienciaLaboral)
						? cvObj.experienciaLaboral.slice(0, 5).map((x: any) => ({
							empresa: String(x?.empresa ?? ''),
							cargo: String(x?.cargo ?? ''),
							area: String(x?.area ?? ''),
							funciones: String(x?.funciones ?? ''),
							fechaInicio: String(x?.fechaInicio ?? ''),
							fechaFin: String(x?.fechaFin ?? ''),
						}))
						: [{ empresa: '', cargo: '', area: '', funciones: '', fechaInicio: '', fechaFin: '' }],
					formacionAcademica: Array.isArray(cvObj?.formacionAcademica)
						? cvObj.formacionAcademica.slice(0, 5).map((x: any) => ({
							institucion: String(x?.institucion ?? ''),
							carrera: String(x?.carrera ?? ''),
							nivel: String(x?.nivel ?? 'Bachiller'),
							estado: String(x?.estado ?? 'Terminado'),
							fechaInicio: String(x?.fechaInicio ?? ''),
						}))
						: [{ institucion: '', carrera: '', nivel: 'Bachiller', estado: 'Terminado', fechaInicio: '' }],
					idiomas: Array.isArray(cvObj?.idiomas)
						? cvObj.idiomas.slice(0, 3).map((x: any) => ({
							idioma: String(x?.idioma ?? ''),
							nivelEscritura: String(x?.nivelEscritura ?? 'MEDIA'),
							nivelLectura: String(x?.nivelLectura ?? 'MEDIA'),
							nivelConversacion: String(x?.nivelConversacion ?? 'MEDIA'),
						}))
						: [{ idioma: '', nivelEscritura: 'MEDIA', nivelLectura: 'MEDIA', nivelConversacion: 'MEDIA' }],
				},

				resultadosPruebas: Array.isArray(c?.resultadosPruebas)
					? c.resultadosPruebas.map((rp: any) => ({
						name: normalizeTestName(rp?.name),
						scores: rp?.scores ?? {},
					}))
					: [{ name: DEFAULT_TEST_NAME, scores: {} }],

				entrevistaEnabled: Boolean(entrevistaObj && typeof entrevistaObj === 'object' && isNonEmptyValue(entrevistaObj)),
				resultadoEntrevista: {
					preguntas: Array.isArray(entrevistaObj?.preguntas)
						? entrevistaObj.preguntas.map((p: any) => ({
							pregunta: String(p?.pregunta ?? ''),
							respuesta: String(p?.respuesta ?? ''),
							calificacion: Number(p?.calificacion ?? 5),
							concepto: String(p?.concepto ?? ''),
						}))
						: [{ pregunta: '', respuesta: '', calificacion: 5, concepto: '' }],
					calificacion: Number(entrevistaObj?.calificacion ?? 5),
					concepto: String(entrevistaObj?.concepto ?? ''),
				},
			})
		}

		if (!form.candidatos.length) form.candidatos.push(JSON.parse(JSON.stringify(form.candidatos[0] ?? { nombre: '' })))
	}

	// CONFIG
	if (template.config && typeof template.config === 'object') {
		if (template.config.service) form.config.service = String(template.config.service) as any
		if (form.config.service !== 'RANKING' && template.config.reportMode) {
			form.config.reportMode = String(template.config.reportMode) as any
		}

		const p = template.config.ponderaciones ?? {}
		form.config.ponderaciones.cv = Number(p.cv ?? form.config.ponderaciones.cv)
		form.config.ponderaciones.pruebas = Number(p.pruebas ?? form.config.ponderaciones.pruebas)
		form.config.ponderaciones.entrevista = Number(p.entrevista ?? form.config.ponderaciones.entrevista)
	}

	guardIssues.value = scanFreeText()
	if (guardIssues.value.length) throw new Error('Template contains unsafe text (possible prompt injection). Fix flagged fields and re-import.')
}

async function onImportFile(e: Event) {
	const input = e.target as HTMLInputElement
	const file = input.files?.[0]
	input.value = ''
	if (!file) return

	try {
		const text = await file.text()
		const json = JSON.parse(text)
		applyTemplate(json)
	} catch (err: any) {
		submitError.value = err?.message ?? 'Failed to import JSON template.'
	}
}

/** ------------ payload builder ------------ **/
function buildPayload() {
	const tiempoAnios = `${form.perfil.requisitos.experienciaLaboral.tiempo} años`

	return {
		perfil: {
			...form.perfil,
			requisitos: {
				...form.perfil.requisitos,
				experienciaLaboral: {
					...form.perfil.requisitos.experienciaLaboral,
					tiempo: tiempoAnios,
				},
			},
		},
		cultura: form.cultura.enabled
			? {
				valores: form.cultura.valores.filter(Boolean),
				estiloTrabajo: form.cultura.estiloTrabajo,
				ritmo: form.cultura.ritmo,
				toleranciaAlError: form.cultura.toleranciaAlError,
				comportamientosDeseados: form.cultura.comportamientosDeseados.filter(Boolean),
				comportamientosNoAceptados: form.cultura.comportamientosNoAceptados.filter(Boolean),
				estiloLiderazgo: form.cultura.estiloLiderazgo,
				nivelEstructura: form.cultura.nivelEstructura,
			}
			: undefined,
		candidatos: form.candidatos.map((c) => ({
			nombre: c.nombre,
			cv: c.cvEnabled ? c.cv : undefined,
			resultadosPruebas: c.resultadosPruebas.map((rp) => ({ name: rp.name, scores: rp.scores })),
			resultadoEntrevista: c.entrevistaEnabled ? c.resultadoEntrevista : undefined,
		})),
		config: {
			service: form.config.service,
			reportMode: form.config.service === 'RANKING' ? null : form.config.reportMode,
			ponderaciones: {
				cv: anyCvPresent.value ? form.config.ponderaciones.cv : 0,
				pruebas: form.config.ponderaciones.pruebas,
				entrevista: anyInterviewPresent.value ? form.config.ponderaciones.entrevista : 0,
			},
		},
	}
}

/** ------------ submit ------------ **/
const submitting = ref(false)
const submitError = ref<string | null>(null)

async function onSubmit() {
	submitError.value = null

	guardIssues.value = scanFreeText()
	if (guardIssues.value.length) {
		submitError.value = 'Algunos textos parecen inseguros (posiblemente prompt injection). Por favor, revisar campos señalados.'
		tab.value = 'Perfil'
		return
	}

	if (ponderacionesSum.value !== 10) {
		submitError.value = 'Ponderaciones debe sumar 10.'
		tab.value = 'Configuración'
		return
	}

	if (!form.perfil.cargo.trim()) {
		submitError.value = 'perfil.cargo es obligatorio.'
		tab.value = 'Perfil'
		return
	}
	if (!form.candidatos.length || !form.candidatos[0]?.nombre.trim()) {
		submitError.value = 'Al menos debe haber un candidato con nombre.'
		tab.value = 'Candidatos'
		return
	}

	const payload = buildPayload()

	submitting.value = true
	try {
		const res = await $fetch('/api/evaluate', { method: 'POST', body: { payload } })
		await navigateTo(`/evaluate/${(res as any).jobId}`)
	} catch (e: any) {
		submitError.value = e?.data?.message ?? e?.message ?? 'Falló al enviar la evaluación.'
	} finally {
		submitting.value = false
	}
}

function addCandidate() {
	if (form.candidatos.length >= 10) return
	const clone = JSON.parse(JSON.stringify(form.candidatos[0]))
	clone.resultadosPruebas = [{ name: DEFAULT_TEST_NAME, scores: {} }]
	form.candidatos.push(clone)
}

function removeCandidate(idx: number) {
	if (form.candidatos.length <= 1) return
	form.candidatos.splice(idx, 1)
}

function addTest(ci: number) {
	form.candidatos[ci]?.resultadosPruebas.push({ name: DEFAULT_TEST_NAME, scores: {} })
}

function removeTest(ci: number, ti: number) {
	form.candidatos[ci]?.resultadosPruebas.splice(ti, 1)
}

/** ------------ collapsible candidates ------------ **/
const openCandidates = ref<Set<number>>(new Set([0]))

function isOpenCandidate(idx: number) {
	return openCandidates.value.has(idx)
}

function toggleCandidate(idx: number) {
	const s = new Set(openCandidates.value)
	if (s.has(idx)) s.delete(idx)
	else s.add(idx)
	openCandidates.value = s
}

function openAllCandidates() {
	openCandidates.value = new Set(form.candidatos.map((_, i) => i))
}

function closeAllCandidates() {
	openCandidates.value = new Set()
}

watch(
	() => form.candidatos.length,
	(len) => {
		const s = new Set<number>()
		for (const i of openCandidates.value) if (i >= 0 && i < len) s.add(i)
		if (s.size === 0 && len > 0) s.add(0)
		openCandidates.value = s
	}
)

function schemaFor(name: TestName) {
	return getTestSchema(name)!
}
</script>

<template>
	<div class="mx-auto w-full max-w-6xl p-6">
		<div class="mb-6 flex items-center justify-between">
			<h1 class="text-2xl font-semibold">Nueva Evaluación</h1>

			<div class="flex items-center gap-3">
				<button class="rounded-lg border border-slate-900 px-4 py-2" type="button" @click="fileInput?.click()">
					Importar JSON
				</button>

				<button class="rounded-lg bg-slate-900 px-4 py-2 text-white disabled:opacity-60" :disabled="submitting" @click="onSubmit">
					{{ submitting ? 'Enviando…' : 'Enviar' }}
				</button>
			</div>
		</div>

		<div v-if="submitError" class="mb-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">
			{{ submitError }}
			<div v-if="guardIssues.length" class="mt-2 text-xs text-red-700">
				<div class="font-semibold">Flagged fields:</div>
				<ul class="list-inside list-disc">
					<li v-for="(g, i) in guardIssues" :key="i">
						{{ g.path }} ({{ g.hits[0]?.reason }})
					</li>
				</ul>
			</div>
		</div>

		<input ref="fileInput" type="file" accept="application/json" class="hidden" @change="onImportFile" />

		<!-- tabs -->
		<div class="mb-6 flex flex-wrap gap-2">
			<button
				v-for="t in tabs"
				:key="t"
				class="rounded-full border px-4 py-2 text-sm"
				:class="t === tab ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-700'"
				@click="tab = t"
			>
				{{ t }}
			</button>
		</div>

		<!-- PERFIL -->
		<div v-if="tab === 'Perfil'">
			<PerfilForm
				:perfil="form.perfil"
				:nivelProfesional="NIVEL_PROFESIONAL"
				:idiomas="IDIOMAS"
				:modalidad="MODALIDAD"
				:seniority="SENIORITY"
			/>
		</div>

		<!-- CULTURA -->
		<div v-else-if="tab === 'Cultura'">
			<CulturaForm
				:cultura="form.cultura"
				:estiloTrabajo="CULT_ESTILO_TRABAJO"
				:ritmo="CULT_RITMO"
				:toleranciaError="CULT_TOL_ERR"
				:estiloLiderazgo="CULT_ESTILO_LIDERAZGO"
				:nivelEstructura="CULT_NIVEL_ESTRUCTURA"
			/>
		</div>

		<!-- CANDIDATOS -->
		<div v-else-if="tab === 'Candidatos'" class="space-y-4">
			<div class="flex flex-wrap items-center justify-between gap-2">
				<div class="text-sm text-slate-600">
					Candidates: <span class="font-semibold text-slate-900">{{ form.candidatos.length }}</span> / 10
				</div>
				<div class="flex items-center gap-2">
					<button class="rounded-lg border px-3 py-2 text-sm" type="button" @click="openAllCandidates">Open all</button>
					<button class="rounded-lg border px-3 py-2 text-sm" type="button" @click="closeAllCandidates">Close all</button>
					<button
						class="rounded-lg bg-slate-900 px-3 py-2 text-sm text-white disabled:opacity-60"
						type="button"
						:disabled="form.candidatos.length >= 10"
						@click="addCandidate"
					>
						+ Add candidate
					</button>
				</div>
			</div>

			<div
				v-for="(c, ci) in form.candidatos"
				:key="ci"
				class="rounded-2xl border bg-white"
			>
				<button
					type="button"
					class="flex w-full items-center justify-between gap-3 px-5 py-4"
					@click="toggleCandidate(ci)"
				>
					<div class="min-w-0 text-left">
						<div class="text-sm font-semibold">
							Candidate {{ ci + 1 }}
							<span v-if="c.nombre?.trim()" class="font-normal text-slate-600">· {{ c.nombre }}</span>
						</div>
						<div class="mt-1 text-xs text-slate-500">
							Tests: {{ c.resultadosPruebas.length }}
							<span class="mx-2">•</span>
							CV: {{ c.cvEnabled ? 'Yes' : 'No' }}
							<span class="mx-2">•</span>
							Interview: {{ c.entrevistaEnabled ? 'Yes' : 'No' }}
						</div>
					</div>

					<div class="flex items-center gap-2">
						<span class="text-xs text-slate-500">{{ isOpenCandidate(ci) ? 'Hide' : 'Show' }}</span>
						<span class="text-slate-500">{{ isOpenCandidate(ci) ? '▾' : '▸' }}</span>
					</div>
				</button>

				<div v-if="isOpenCandidate(ci)" class="border-t px-5 py-5">
					<CandidateForm
						:candidate="c"
						:candidateIndex="ci"
						:testSchemas="TEST_SCHEMAS"
						:schemaFor="schemaFor"
						@removeCandidate="removeCandidate"
						@addTest="addTest"
						@removeTest="removeTest"
					/>
				</div>
			</div>
		</div>

		<!-- CONFIG -->
		<div v-else class="space-y-6">
			<ConfigForm
				:config="form.config"
				:anyCvPresent="anyCvPresent"
				:anyInterviewPresent="anyInterviewPresent"
			/>
		</div>
	</div>
</template>
